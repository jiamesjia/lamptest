import { withInstall } from '/@/utils';
import cardList from './src/CardList.vue';

export const CardList = withInstall(cardList);
