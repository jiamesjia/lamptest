import { withInstall } from '/@/utils';
import avatar from './src/Avatar.vue';

export const AvatarPreview = withInstall(avatar);
