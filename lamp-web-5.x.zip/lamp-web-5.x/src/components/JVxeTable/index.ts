export { registerJVxeTable } from './src/install';
// export { default as JVxeTable } from './src/JVxeTable';
// export { deleteComponent } from './src/componentMap';
// export { registerComponent, registerAsyncComponent } from './src/utils/registerUtils';
