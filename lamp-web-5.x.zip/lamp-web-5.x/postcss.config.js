module.exports = {
  plugins: {
    autoprefixer: {}

  },
};
